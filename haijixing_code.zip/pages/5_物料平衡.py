# -*- coding: utf-8 -*-
from __future__ import annotations

import os
import sqlite3

import numpy as np
import pandas as pd
import plotly.express as px
import streamlit as st

st.set_page_config(page_title="物料平衡 | 海吉星果蔬项目", layout="wide")

from utils.bootstrap import bootstrap_page
from utils.config import load_thresholds
from utils.definitions import DEFINITIONS_MD
from utils.paths import get_db_path
from utils.sidebar_filters import render_global_sidebar_by_df
from utils.snapshot import get_active_snapshot_id


DB_PATH = get_db_path()
user = bootstrap_page(DB_PATH)
ACTIVE_SNAPSHOT_ID = get_active_snapshot_id(DB_PATH)


def _as_bool(v) -> bool:
    if isinstance(v, bool):
        return v
    if v is None:
        return False
    return str(v).strip().lower() in {"1", "true", "yes", "y", "on"}


DEBUG = _as_bool(st.secrets.get("DEBUG", False))
st.sidebar.caption(f"DEBUG(secrets) raw: `{st.secrets.get('DEBUG', None)}`")


if DEBUG:
    st.sidebar.markdown("### 🔎 Debug")
    st.sidebar.caption(f"DB_PATH: `{DB_PATH}`")
    st.sidebar.caption(f"exists: `{os.path.exists(DB_PATH)}`")
    if os.path.exists(DB_PATH):
        st.sidebar.caption(f"size: `{os.path.getsize(DB_PATH)} bytes`")

    @st.cache_data(ttl=300)
    def _debug_read_one_row(db_path: str):
        conn = sqlite3.connect(db_path)
        df = pd.read_sql_query(
            "SELECT * FROM fact_daily_ops WHERE snapshot_id=? ORDER BY date LIMIT 1",
            conn,
            params=(ACTIVE_SNAPSHOT_ID,),
            parse_dates=["date"],
        )
        conn.close()
        row0 = df.to_dict(orient="records")[0] if not df.empty else {}
        return list(df.columns), row0

    if os.path.exists(DB_PATH):
        try:
            cols, row0 = _debug_read_one_row(DB_PATH)
            st.sidebar.caption(f"cols: `{len(cols)}`")
            with st.sidebar.expander("columns"):
                st.write(cols)
            with st.sidebar.expander("row[0]"):
                st.write(row0)
        except Exception as e:
            st.sidebar.error("Read DB failed:")
            st.sidebar.exception(e)
            st.stop()
    else:
        st.sidebar.error("DB file not found. Stop.")
        st.stop()


@st.cache_data(ttl=5)
def load_data() -> pd.DataFrame:
    conn = sqlite3.connect(DB_PATH)
    df = pd.read_sql_query(
        "SELECT * FROM fact_daily_ops WHERE snapshot_id=? ORDER BY date",
        conn,
        params=(ACTIVE_SNAPSHOT_ID,),
        parse_dates=["date"],
    )
    conn.close()
    return df


st.title("物料平衡")

with st.expander("📌口径说明", expanded=False):
    st.markdown(DEFINITIONS_MD)

df = load_data()
if df.empty:
    st.warning("数据库为空。请先导入 Excel。")
    st.stop()

df["date"] = pd.to_datetime(df["date"])

start_date, end_date, date_meta = render_global_sidebar_by_df(df, date_col="date")
st.caption(f"当前筛选区间：{date_meta['label']}")

dfr = df[
    (df["date"].dt.date >= start_date) &
    (df["date"].dt.date <= end_date)
].copy()

if dfr.empty:
    st.warning("当前筛选区间内无数据，请调整侧边栏时间范围。")
    st.stop()

incoming = float(dfr["incoming_ton"].sum(skipna=True))
slag = float(dfr["slag_total_ton"].sum(skipna=True))
rate = np.nan if incoming == 0 else slag / incoming

k1, k2, k3 = st.columns(3)
k1.metric("来料(吨)", f"{incoming:,.0f}")
k2.metric("出渣合计(吨)", f"{slag:,.0f}")
k3.metric("出渣率(吨/吨)", "-" if np.isnan(rate) else f"{rate:.3f}")

st.divider()
st.subheader("出渣率（日）")

valid_in = dfr["incoming_ton"].where(dfr["incoming_ton"] > 0)
dfr["slag_rate"] = dfr["slag_total_ton"] / valid_in

fig = px.line(dfr, x="date", y="slag_rate", title="出渣率（日）")
st.plotly_chart(fig, use_container_width=True)

st.subheader("出渣率分布")
hist_df = dfr.dropna(subset=["slag_rate"]).copy()
hist_df = hist_df[hist_df["slag_rate"].between(0, 2)]

fig = px.histogram(hist_df, x="slag_rate", nbins=30, title="出渣率分布")
st.plotly_chart(fig, use_container_width=True)

st.subheader("异常日（出渣率过高）")
th = load_thresholds()
threshold = st.number_input(
    "阈值（出渣率 > 阈值 列为异常）",
    value=float(th.slag_rate_high),
    step=0.05,
    min_value=0.0,
    max_value=2.0,
)

abn = (
    dfr.dropna(subset=["slag_rate"])
    .loc[
        lambda x: x["slag_rate"] > threshold,
        ["date", "incoming_ton", "slag_total_ton", "slag_rate"],
    ]
    .sort_values("slag_rate", ascending=False)
)

st.dataframe(abn, use_container_width=True, hide_index=True)